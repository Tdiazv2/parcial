package Principal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

import logica.Peon;
import logica.Pieza;
import logica.Rey;
import logica.Torre;

public class Interface {
	

	
	Integer x = Integer.parseInt(input("Por favor ingrese la cordenada x"));
	
	
	
	Integer y = Integer.parseInt(input("Por favor ingrese la cordenada y "));
	
	String ficha = input("Por favor ingrese la ficha que desea saber ");{
	
	
	
	if (ficha == "peon") {
		Peon ficha = new Peon(x,y);
		
		
	}
	if (ficha == "torre") {
		Torre ficha = new Torre(x,y);
		
		
	}
	if (ficha == "rey") {
		Rey ficha = new Rey(x,y);
		
		
	}
	HashMap<String, Integer> res;
	res = Pieza.ficha.getMovimiento();
	System.out.println(res);
	
	
	}
	public String input(String mensaje)
	{
		try
		{
			System.out.print(mensaje + ": ");
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			return reader.readLine();
		}
		catch (IOException e)
		{
			System.out.println("Error leyendo de la consola");
			e.printStackTrace();
		}
		return null;
	}
}

