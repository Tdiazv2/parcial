package logica;

import java.util.HashMap;

public abstract class Pieza {
	protected int cordenadax;
	protected int cordenaday;

	
	
	public int getCordenadax() {
		return cordenadax;
	}
	public void setCordenadax(int cordenadax) {
		this.cordenadax = cordenadax;
	}
	public int getCordenaday() {
		return cordenaday;
	}
	public void setCordenaday(int cordenaday) {
		this.cordenaday = cordenaday;
	}
	public Pieza (int cordenadax, int cordenaday) {
		this.cordenadax = cordenadax;
		this.cordenaday = cordenaday;
		
				
				
				
	}
	public abstract HashMap<String, Integer> getMovimiento();
	
			
}
