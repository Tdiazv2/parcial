package logica;

import java.util.HashMap;

public class Rey extends Pieza{

	public Rey(int cordenadax, int cordenaday) {
		super(cordenadax, cordenaday);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<String, Integer> getMovimiento() {
HashMap<String, Integer> direction = null;
		
		int mov1 = 1 ;
		if (cordenaday == 1) {
			mov1 = 0;
		}
		direction.put("arriba", mov1);
		
		int mov2 = 1 ;
		if (cordenaday == 8) {
			mov2 = 0;
		}
		direction.put("abajo", mov2);
		int mov3 = 1 ;
		if (cordenadax == 1) {
			mov3 = 0;
		}
		direction.put("izquierda", mov3);
		int mov4 = 1 ;
		if (cordenadax == 8) {
			mov4 = 0;
		}
		direction.put("derecha", mov4);
		
		
		
		return direction;
	}

}
