package logica;

import java.util.HashMap;

public class Torre extends Pieza{

	public Torre(int cordenadax, int cordenaday) {
		super(cordenadax, cordenaday);
		// TODO Auto-generated constructor stub
	}
	public HashMap<String, Integer> getMovimiento() {
		HashMap<String, Integer> direction = null;
		
		int mov1 = cordenaday + 7 - 8 ;
		direction.put("arriba", mov1);
		
		int mov2 = cordenaday -8 + 7;
		direction.put("Abajo", mov2);
		
		int mov3 = cordenaday + 7 - 8 ;
		direction.put("derecha", mov3);
		
		int mov4 = cordenaday -8 + 7;
		direction.put("izquierda", mov4);
		
		
		
		return direction;
		
				
				
	}

}
