package logica;

import java.util.HashMap;

public class Peon extends Pieza{
	
	
	private HashMap<String, Integer> direction;
	public Peon(int cordenadax, int cordenaday) {
		super(cordenadax, cordenaday);
		// TODO Auto-generated constructor stub
	}
	public HashMap<String,Integer> getMovimiento() {
		Integer mov = 1;
		
		if (cordenadax ==7) {
			mov = 2;
		}
		else if (cordenadax == 1) {
			mov = 0;
		}
		direction = null;
		direction.put("Arriba", mov);
		
		
		
		return  direction;
		
		
		
		
	}
}
